import {TestBed, async, ComponentFixture, fakeAsync, flush} from '@angular/core/testing';
import {AppComponent} from './app.component';
import {CUSTOM_ELEMENTS_SCHEMA} from "@angular/core";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {Router} from '@angular/router';
import {RouterTestingModule} from '@angular/router/testing';
import {AppService, IUser} from './app.service';
import {Location} from "@angular/common";
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';
import { AuthGuard } from './guard/auth.guard';

const generateRandomString = () => {
  return (Math.random() + 1).toString(36).substring(7);
}

const generateRandomNumber = () => {
  return Math.floor((Math.random() * 10000) + 1);
}

function generateMockUsers(userName: string, status: string): IUser {
  return {
    fName: status,
    userName: userName,
    password: generateRandomString(),
    email: `${generateRandomString()}@${generateRandomString()}.com`,
    lName: generateRandomString(),
    phoneNo: generateRandomString(),
    state: `${generateRandomNumber()}${generateRandomNumber()}`
  }
}

const testIdList = {
  appNav: {
    appNav: 'app-nav',
    loginRouteLink: 'login-router-link',
    profileRouteLink: 'profile-router-link',
  },
  loginForm: {
    userNameInput: 'app-input-userName',
    passwordInput: 'app-input-password',
    loginError: 'login-error',
    login: 'login-button'
  },
  profileCard: 'profile-card',
  logoutBtn: 'logout-btn'
};

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let location: Location;
  let router: Router;
  let compiled;

  let appNav: HTMLElement, loginRouteLink: HTMLElement, profileRouteLink: HTMLElement,
    userNameInput: HTMLInputElement, passwordInput: HTMLInputElement, loginError: HTMLElement,
    loginBtn: HTMLButtonElement, profileCard:  HTMLElement, logoutBtn: HTMLButtonElement;

  const mockUserName = generateRandomString();
  const mockStatus = generateRandomString();
  const mockUsers = [0,1,2,3].map(() => generateMockUsers(mockUserName, mockStatus));
  const firstMock = mockUsers[(Math.floor(Math.random() * mockUsers.length))];


  async function getElements() {
    const appNav = fixture.debugElement.nativeElement.querySelector(`[data-test-id = ${testIdList.appNav.appNav}]`) as HTMLElement;
    const loginRouteLink = fixture.debugElement.nativeElement.querySelector(`[data-test-id = ${testIdList.appNav.loginRouteLink}]`) as HTMLElement;
    const profileRouteLink = fixture.debugElement.nativeElement.querySelector(`[data-test-id = ${testIdList.appNav.profileRouteLink}]`) as HTMLElement;
    const userNameInput = fixture.debugElement.nativeElement.querySelector(`[data-test-id = ${testIdList.loginForm.userNameInput}]`) as HTMLInputElement;
    const passwordInput = fixture.debugElement.nativeElement.querySelector(`[data-test-id = ${testIdList.loginForm.passwordInput}]`) as HTMLInputElement;
    const loginError = fixture.debugElement.nativeElement.querySelector(`[data-test-id = ${testIdList.loginForm.loginError}]`) as HTMLElement;
    const loginBtn = fixture.debugElement.nativeElement.querySelector(`[data-test-id = ${testIdList.loginForm.login}]`) as HTMLButtonElement;
    const profileCard = fixture.debugElement.nativeElement.querySelector(`[data-test-id = ${testIdList.profileCard}]`) as HTMLElement;
    const logoutBtn = fixture.debugElement.nativeElement.querySelector(`[data-test-id = ${testIdList.logoutBtn}]`) as HTMLButtonElement;
    return {
      appNav,
      loginRouteLink,
      profileRouteLink,
      userNameInput,
      passwordInput,
      loginError,
      loginBtn,
      profileCard,
      logoutBtn
    };
  }

  const detectChanges = async () => {
    await fixture.detectChanges();
    await fixture.whenStable();
    await fixture.whenStable();
    ({appNav,loginRouteLink,profileRouteLink,userNameInput,passwordInput,loginError,loginBtn,profileCard,logoutBtn
    } = (await getElements()));
  }

  async function inputFireEvent(control: HTMLInputElement, value: string) {
    control.value = value;
    control.dispatchEvent(new Event('change'));
    control.dispatchEvent(new Event('input'));
    await detectChanges();
  }

  async function fireEvent(control: HTMLElement | HTMLButtonElement) {
    control.click();
    await detectChanges();
  }

  const navigate = async (route: string) => {
    await fixture.ngZone.run(async () => {
      await router.navigateByUrl(route);
      flush();
    });
    await detectChanges();
  }

  beforeEach(async(() => {

    class MockAppService extends AppService {
      public userList = mockUsers;
   }


    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        ProfileComponent,
        LoginComponent
      ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule.withRoutes([
          { path:'', component: LoginComponent },
          { path:'profile', component: ProfileComponent, canActivate: [AuthGuard] },
        ]),
      ],
      providers: [{provide: AppService, useClass: MockAppService}],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(fakeAsync(async () => {
    
    router = TestBed.get<Router>(Router);
    location = TestBed.get(Location);
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    compiled = fixture.debugElement.nativeElement;
    await navigate('/');
    await detectChanges();
  }));

  it('App is available with links', fakeAsync(async () => {
    expect(appNav).toBeTruthy();
    expect(loginRouteLink).toBeTruthy();
    expect(profileRouteLink).not.toBeTruthy();
  }));

  it('Initial login form is empty', fakeAsync(async () => {
    expect(userNameInput.value).toBe('');
    expect(passwordInput.value).toBe('');
    expect(loginBtn.disabled).toBeTruthy();
  }));

  it('Login is disabled if username is empty', fakeAsync(async () => {
    await inputFireEvent(passwordInput, firstMock.password);
    expect(loginBtn.disabled).toBeTruthy();
  }));

  it('Login is disabled if password is empty', fakeAsync(async () => {
    await inputFireEvent(userNameInput, firstMock.userName);
    expect(loginBtn.disabled).toBeTruthy();
  }));

  it('Login the form with wrong userName', fakeAsync(async () => {
    await inputFireEvent(userNameInput, firstMock.userName+firstMock.userName);
    await inputFireEvent(passwordInput, firstMock.password);
    expect(loginBtn.disabled).not.toBeTruthy();
    await fireEvent(loginBtn);
    expect(userNameInput.value).toBe('');
    expect(passwordInput.value).toBe('');
    expect(loginError).toBeTruthy();
    expect(router.url).not.toBe('/profile');
  }));

  it('Login the form with wrong password', fakeAsync(async () => {
    await inputFireEvent(userNameInput, firstMock.userName);
    await inputFireEvent(passwordInput, firstMock.password+firstMock.password);
    expect(loginBtn.disabled).not.toBeTruthy();
    await fireEvent(loginBtn);
    expect(userNameInput.value).toBe('');
    expect(passwordInput.value).toBe('');
    expect(loginError).toBeTruthy();
    expect(router.url).not.toBe('/profile');
  }));

  it('check authgGuard is working or not - direct goto profile', fakeAsync(async () => {
    await navigate('/profile');
    await detectChanges();
    expect(router.url).not.toBe('/profile');
  }));

  it('Login the form with valid UserName and Password', fakeAsync(async () => {
    await inputFireEvent(userNameInput, firstMock.userName);
    await inputFireEvent(passwordInput, firstMock.password);
    expect(loginBtn.disabled).not.toBeTruthy();
    await fireEvent(loginBtn);
    expect(loginError).not.toBeTruthy();
    expect(router.url).toBe('/profile');
  }));

  it('Hide a Login URL when user sucesfully Login', fakeAsync(async () => {
    await inputFireEvent(userNameInput, firstMock.userName);
    await inputFireEvent(passwordInput, firstMock.password);
    expect(loginBtn.disabled).not.toBeTruthy();
    await fireEvent(loginBtn);
    expect(loginError).not.toBeTruthy();
    expect(router.url).toBe('/profile');
    expect(loginRouteLink).not.toBeTruthy();
    expect(profileRouteLink).toBeTruthy();
  }));

  it('display user details when user sucesfully login', fakeAsync(async () => {
    await inputFireEvent(userNameInput, firstMock.userName);
    await inputFireEvent(passwordInput, firstMock.password);
    expect(loginBtn.disabled).not.toBeTruthy();
    await fireEvent(loginBtn);
    await detectChanges();
    expect(profileCard.textContent).toMatch(firstMock.fName);
    expect(profileCard.textContent).toMatch(firstMock.lName);
    expect(profileCard.textContent).toMatch(firstMock.email);
    expect(profileCard.textContent).toMatch(firstMock.phoneNo);
    expect(profileCard.textContent).toMatch(firstMock.userName);
    expect(profileCard.textContent).toMatch(firstMock.state);
    expect(logoutBtn).toBeTruthy();
  }));

  it('click on logout and user need to reirect on login screen', fakeAsync(async () => {
    await inputFireEvent(userNameInput, firstMock.userName);
    await inputFireEvent(passwordInput, firstMock.password);
    await fireEvent(loginBtn);
    await detectChanges();
    await fireEvent(logoutBtn);
    await detectChanges();
    expect(router.url).toBe('/');
  }));

  it('click on logout and user need to reirect on login screen and try to goto profile screen - need to check user session is destory or not', fakeAsync(async () => {
    await inputFireEvent(userNameInput, firstMock.userName);
    await inputFireEvent(passwordInput, firstMock.password);
    await fireEvent(loginBtn);
    await detectChanges();
    await fireEvent(logoutBtn);
    await detectChanges();
    expect(router.url).toBe('/');
    await navigate('/profile');
    await detectChanges();
    expect(router.url).not.toBe('/profile');
  }));

  it('check entire application flow', fakeAsync(async () => {

    await inputFireEvent(userNameInput, firstMock.userName);
    await inputFireEvent(passwordInput, firstMock.password);
    await fireEvent(loginBtn);
    await detectChanges();

    expect(profileCard.textContent).toMatch(firstMock.fName);
    expect(profileCard.textContent).toMatch(firstMock.lName);
    expect(profileCard.textContent).toMatch(firstMock.email);
    expect(profileCard.textContent).toMatch(firstMock.phoneNo);
    expect(profileCard.textContent).toMatch(firstMock.userName);
    expect(profileCard.textContent).toMatch(firstMock.state);

    await fireEvent(logoutBtn);
    await detectChanges();

    expect(userNameInput.value).toBe('');
    expect(passwordInput.value).toBe('');
    expect(loginBtn.disabled).toBeTruthy();

  }));
});