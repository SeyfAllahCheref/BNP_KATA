export interface IUser {
  fName: string;
  lName: string;
  userName: string;
  password: string;
  phoneNo: string;
  email: string;
  state: string;
}

export class AppService {

  public userList: IUser[] = [
    {
      fName: 'John',
      lName: "Doe",
      userName: "John",
      password: "John@123",
      email: "john@hackerrank.com",
      phoneNo: "+1 9876543210",
      state: "California"
    },
    {
      fName: 'Alexa',
      lName: "Musk",
      userName: "Alexa",
      password: "Alexa@123",
      email: "alexa@hackerrank.com",
      phoneNo: "+1 1111111111",
      state: "California"
    }
  ];
}
