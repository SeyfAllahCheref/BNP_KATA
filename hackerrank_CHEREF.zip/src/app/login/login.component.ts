import { Component, OnInit } from '@angular/core';
import { Validators } from '@angular/forms';
import { AppService } from '../app.service';
import { Router } from '@angular/router';
import { UntypedFormBuilder, UntypedFormGroup  } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit{

  constructor(private appService: AppService, private router: Router, private formBuilder: UntypedFormBuilder, private authService: AuthService) {}

  userConnected = false;
  form: UntypedFormGroup;
  error: string

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      userName: ['', [Validators.required]],
      password: ['', [Validators.required]]
    })
  }

  submit(): void {
    this.appService.userList.forEach(user => {
      if (user.password === this.form.value['password'] && user.userName === this.form.value['userName']) {
        this.authService.isUserLoggedIn.next(true);
        this.userConnected = true;
        this.router.navigate(['/profile']);
      }
    })
    if (!this.userConnected) {
      this.error = 'Invalid credentials'
    }
  }
}
