import {Component, OnInit} from '@angular/core';
import {AppService, IUser} from "../app.service";
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit{

  constructor(private appService: AppService, private router: Router) {
  }

  ngOnInit() {
    
  }

}
